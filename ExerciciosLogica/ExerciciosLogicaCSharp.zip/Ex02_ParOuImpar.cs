// Ex 2: Verificar se é par ou ímpar
// Peça um número e diga se ele é par ou ímpar.

using System;

class Program
{
    static void Main()
    {
        Console.Write("Digite um número: ");
        int numero = int.Parse(Console.ReadLine());

        if (numero % 2 == 0)
            Console.WriteLine("Par");
        else
            Console.WriteLine("Ímpar");
    }
}
