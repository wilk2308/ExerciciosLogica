// Ex 3: Calcular média de 3 notas
// Peça 3 notas e mostre a média e se o aluno está aprovado (>= 7).

using System;

class Program
{
    static void Main()
    {
        Console.Write("Digite a primeira nota: ");
        double n1 = double.Parse(Console.ReadLine());

        Console.Write("Digite a segunda nota: ");
        double n2 = double.Parse(Console.ReadLine());

        Console.Write("Digite a terceira nota: ");
        double n3 = double.Parse(Console.ReadLine());

        double media = (n1 + n2 + n3) / 3;

        Console.WriteLine("Média: " + media);

        if (media >= 7)
            Console.WriteLine("Aprovado");
        else
            Console.WriteLine("Reprovado");
    }
}
