// Ex 5: Contar até 10 com while
// Mostre os números de 1 a 10 usando while.

using System;

class Program
{
    static void Main()
    {
        int i = 1;
        while (i <= 10)
        {
            Console.WriteLine(i);
            i++;
        }
    }
}
