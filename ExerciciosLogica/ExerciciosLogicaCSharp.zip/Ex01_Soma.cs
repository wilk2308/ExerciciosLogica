// Ex 1: Soma de dois números
// Peça dois números ao usuário e mostre a soma.

using System;

class Program
{
    static void Main()
    {
        Console.Write("Digite o primeiro número: ");
        int a = int.Parse(Console.ReadLine());

        Console.Write("Digite o segundo número: ");
        int b = int.Parse(Console.ReadLine());

        Console.WriteLine("Soma: " + (a + b));
    }
}
